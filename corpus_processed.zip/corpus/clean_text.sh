for f in *.txt
do
	echo "Processing $f file..."
	cat $f | tr -d '[:punct:]' | tr -d '[:digit:]' | tr -d '[«»!@#$%^*}{|£¢§]' | tr '[:upper:]' '[:lower:]' | tr '[\n\r]' ' ' | tr -s ' ' > c_$f
done

